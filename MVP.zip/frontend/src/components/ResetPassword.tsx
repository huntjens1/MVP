export default function ResetPassword() {
  return (
    <section className="max-w-md mx-auto mt-24 bg-calllogix-card p-8 rounded-2xl shadow-xl">
      <h2 className="text-2xl font-black text-calllogix-primary mb-8">Reset wachtwoord</h2>
      <div className="text-calllogix-text">Resetfunctie nog niet geïmplementeerd.</div>
    </section>
  );
}
