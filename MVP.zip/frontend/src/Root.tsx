import App from "./App";

export default function Root() {
  return <App />;
}
